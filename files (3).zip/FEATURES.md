# La Cascada — New Features Deployment Guide

---

## Files to Deploy

### → `static/` folder
| File | Action |
|---|---|
| `animations.js` | **Replace** existing |
| `menu_search.css` | **NEW** — add as extra `<link>` in `menu.html` |

### → `templates/` folder
| File | Action |
|---|---|
| `menu.html` | **Replace** existing (search bar added) |
| `thankyou.html` | **NEW** — add to templates folder |

### → Root project folder (next to `App.py`)
| File | Action |
|---|---|
| `App.py` | **Replace** existing |

### → `static/` folder
| File | Action |
|---|---|
| `thankyou.css` | **NEW** — add to static folder |

---

## One-Time `menu.html` Change

Add the search CSS link in `menu.html` `<head>` alongside the existing menu.css link:

```html
<link rel="stylesheet" href="{{ url_for('static', filename='menu.css') }}">
<link rel="stylesheet" href="{{ url_for('static', filename='menu_search.css') }}">  <!-- ADD THIS -->
```

---

## Feature Breakdown

---

### 1. 🔍 Menu Search & Live Filter
**Files:** `menu.html` (search bar HTML + JS), `menu_search.css`

Type anything into the search bar — cards filter in real time across all sections and categories. Searches English and Arabic names and descriptions simultaneously. Bilingual: placeholder auto-updates on language toggle.

- Per-group "No results in this section" message
- Global "No dishes found" message when nothing matches at all
- Clear (×) button appears when search is active
- Sections with zero matches collapse entirely
- Re-runs automatically on language switch

---

### 2. 📊 Open / Closed Status Badge
**File:** `animations.js` → `initOpenStatus()`

Injected automatically into every page header next to the language button. No template changes needed.

Shows:
- 🟢 **Open** (green pulse dot) with "Closes HH:MM"
- ⚫ **Closed** with "Opens HH:MM"

Updates every 60 seconds. Bilingual (Arabic/English). To change hours, edit in `animations.js`:
```js
const LC_HOURS = {
    lunch:  { open: 12 * 60,      close: 14 * 60 + 30 },  // 12:00–14:30
    dinner: { open: 19 * 60,      close: 23 * 60      }   // 19:00–23:00
};
```

---

### 3. 📢 Announcement Banner
**File:** `animations.js` → `LC_ANNOUNCEMENT` config at top of file

Appears at the top of every page. Dismissed per-device via `localStorage` (stays hidden after dismiss until you change the `id`).

To update the banner, edit the config at the top of `animations.js`:
```js
const LC_ANNOUNCEMENT = {
    active:   true,           // false = hide everywhere
    id:       'ramadan-2025-v1',  // change to re-show for dismissed users
    text_en:  '🌙 Ramadan Special Menu Available — Iftar & Suhoor',
    text_ar:  '🌙 قائمة رمضان الخاصة متاحة الآن — إفطار وسحور',
    link:     '/menu',
    link_en:  'View Menu',
    link_ar:  'عرض القائمة'
};
```

To hide the banner: set `active: false`. To show it again to all users (including those who dismissed): change the `id` to anything new.

---

### 4. ✅ Reservation Thank-You Page
**Files:** `thankyou.html`, `thankyou.css`, `App.py`

After submitting a reservation, guests are redirected to `/reservation/confirmed` instead of back to the form. Shows:
- Animated gold checkmark ring with ✦ symbol
- "We'll be expecting you" heading
- Guest name, date, and time from the submitted form
- "Our team will be in touch" note
- Back to Home + View Menu buttons
- Gold ember particles + slow card float animation
- Respects current language (Arabic/English)

Flask session passes the data across the redirect. `session.pop()` clears it after display so refreshing the page still works gracefully (just shows no details).

---

### 5. 🔐 Admin Panel — Obscure URL + Logo Easter Egg

#### URL Change
The login URL has been changed from `/admin/login` to `/lc-portal-hrg`.

All internal Flask redirects still work because they use `url_for('admin_login')` (the **function name**, not the URL). The only thing that changed is what you type in the browser.

**To change the URL**, edit two places:
1. `App.py` line ~326: `@app.route('/lc-portal-hrg', ...)`
2. `animations.js` line ~14: `const LC_ADMIN_PATH = '/lc-portal-hrg';`
Both must match.

#### Logo Easter Egg
Click the **La Cascada** logo **5 times rapidly** from any page. After the 5th click within 2.2 seconds, the page fades out and redirects to the admin portal. Works on every page (handled in `animations.js`).

No visible indicator — it's completely invisible to guests.

---

### 6. 💬 WhatsApp Floating Button
**File:** `animations.js` → `initWhatsApp()`

A green WhatsApp button appears fixed in the bottom-right corner on every page, with a pulsing ring animation. Tapping/clicking opens a pre-filled WhatsApp chat.

To change the number or message, edit in `animations.js`:
```js
const LC_WHATSAPP = {
    number:  '201554089639',
    text_en: 'Hello, I would like to enquire about La Cascada.',
    text_ar: 'مرحباً، أود الاستفسار عن لا كاسكادا.'
};
```

---

### 7. ↑ Back-to-Top Button
**File:** `animations.js` → `initBackToTop()`

Appears after scrolling 500px down, fixed above the WhatsApp button. Smooth scrolls to top on click. Auto-hides when near the top. No configuration needed.

---

### 8. ▬ Scroll Progress Bar
**File:** `animations.js` → `initScrollProgress()`

A 2px gold gradient line at the very top of the viewport fills as you scroll down the page. Animates with `transition: width 0.08s linear` for smoothness. Sits above everything at `z-index: 100000`. No configuration needed.

---

### 9. 🔍 Dish Lightbox
**File:** `animations.js` → `initLightbox()`

When the dish detail modal is open, clicking the food photo expands it to full-screen with a blur backdrop. A `zoom-in` cursor appears on hover to hint at the interaction. Close with ✕, Escape key, or clicking the backdrop.

Works automatically with the existing modal — no additional HTML changes needed.

---

## Quick Checklist After Deploy

- [ ] Menu search bar appears below the IFTAR/SUHOOR links
- [ ] Typing "grill" shows only matching cards
- [ ] Clear × button appears and clears the search
- [ ] Open/Closed badge visible in header on all pages
- [ ] Announcement banner shows on first visit, dismisses correctly
- [ ] Reservation form submits → lands on `/reservation/confirmed` with name/date/time
- [ ] Gold ✦ checkmark animates on thank-you page
- [ ] `/admin/login` now returns 404 (correct)
- [ ] `/lc-portal-hrg` shows admin login (correct)
- [ ] Clicking La Cascada logo 5× rapidly redirects to admin portal
- [ ] WhatsApp button visible bottom-right, opens pre-filled chat
- [ ] Back-to-top arrow appears after scrolling
- [ ] Progress bar fills at top of page
- [ ] Clicking dish image in modal opens lightbox

---

## Changing the Admin URL Later

If you ever want to change `/lc-portal-hrg` to something else:

1. **`App.py`**: Change `@app.route('/lc-portal-hrg', ...)` to your new path
2. **`animations.js`**: Change `const LC_ADMIN_PATH = '/lc-portal-hrg';` to the same path

That's it. Everything else uses `url_for('admin_login')` internally.
